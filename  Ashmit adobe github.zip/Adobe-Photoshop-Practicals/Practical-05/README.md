# Practical 05 — Creative Effects

## Student Details
- Name: Ashmit
- Roll Number: 067
- Course: BCA

## Objective
To complete the practical 05 practical using Adobe Photoshop tools.

## Tools / techniques
- Layers and selection tools
- Text and shape tools
- Color correction and effects (as applicable)

## Output
The included JPG is a simple starter/reference design. Open or recreate it in Adobe Photoshop, use the required tools from the assignment, and save an editable PSD file before submission.

## Files
- `Practical_05_Ashmit_067.jpg` — JPG reference/export
- `Practical_05_Ashmit_067.psd` — save this editable file from Photoshop
